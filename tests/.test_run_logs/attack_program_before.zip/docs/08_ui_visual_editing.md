# 亲自可视化编辑工坊 UI

主界面从 `addons/stg_maker/studio.tscn` 编辑，公共样式从 `addons/stg_maker/ui/studio_theme.tres` 编辑。这两份资源同时用于 Godot 插件和独立工坊。首次改造保留原来的外观与功能，游戏资产格式没有改变。

## 打开与预览

1. 使用 `Open Editor.cmd` 打开工程。在 Godot 左侧「文件系统」中双击 `addons/stg_maker/studio.tscn`，切换到顶部 **2D** 工作区。
2. 左侧「场景」树中的节点就是保存的真实 UI。选择节点，在右侧 Inspector 修改属性。若区域没显示，先展开它的父节点；隐藏的高级工具、关卡、曲线区域可临时打开「Visibility → Visible」进行设计，运行时仍按当前工作区显示。
3. **Ctrl+S** 保存场景。编辑本场景时只显示静态界面与占位提示，不加载上次制作项目、不模拟战斗、不启动草稿计时器。
4. 按 **F6** 运行当前场景，查看真实数据与交互。也可以用 `Run Studio.cmd` 启动独立工坊。插件主工作区已经加载的实例不会随磁盘修改自动重建；保存后在「项目设置 → 插件」关闭再启用 STGMaker，或者重新打开 Godot。

`main.tscn` 是游戏入口；修改工坊布局应打开上面的 `studio.tscn`。

## 调整布局

根节点下面的 `WorkspaceScroll → layout_margin → layout_outer` 包含顶部栏、主工作区及底部状态。

| 节点 | 可调整的内容 |
| --- | --- |
| `HeaderPanel` / `HeaderRow` / `toolbar` | 顶部排列、按钮顺序、工具栏伸展与换行 |
| `MainSplit` / `PreviewInspectorSplit` | 左右区域划分与分隔位置 |
| `LibraryPanel` / `library_panel` | 资源栏外框和内容；在 `library_panel` 的 Custom Minimum Size → X 改侧栏最小宽度 |
| `PreviewPanel` / `PreviewBody` | 预览区标题、工具及预览内容的排列 |
| `InspectorPanel` / `InspectorBody` / `inspector_scroll` | 属性区外框、工具条、页签和滚动区域；在 `inspector_scroll` 改属性区最小宽度 |
| `layout_margin` | Theme Overrides → Constants 中的四边留白 |
| `layout_outer` | Theme Overrides → Constants → Separation 中的区域间距 |
| `canvas_slot` / `flow_editor_slot` | 战斗与行为流程的占位区域、最小尺寸及伸展规则 |
| `level_panel` / `timeline_scroll` / `curve_panel` | 时间轴与曲线区域的位置和设计尺寸 |
| `file_status` | 底部状态文字的布局与局部样式 |

Godot 的 Container 自动排列子控件。改变同一容器内节点的顺序即可改变排列；用 **Layout → Container Sizing** 控制 Fill、Expand，用 **Custom Minimum Size** 控制最小尺寸。容器子控件的位置由布局计算，直接拖动坐标通常会被重新排列。

初始设计以 1440×900 为参考。修改后至少检查 1100×760 和较大的窗口；高缩放时外层允许滚动。可以在运行工坊的「界面」菜单选择整体大小和基础字号。自动字号使用 Theme 中的基础字号；显式字号偏好仍优先。

## 编辑颜色与按钮

双击 `studio_theme.tres` 打开底部 Theme 编辑器，使用预览和类型选择器调整样式。选中某个控件时，其 Theme Type Variation 决定它使用哪一类样式。

| Theme 类型 | 用途 |
| --- | --- |
| `STGPrimaryButton` | 保存、开始测试等主要按钮 |
| `STGActionButton` / `STGNavigationButton` | 普通操作与分类导航 |
| `STGLinkButton` / `STGDangerButton` | 引用返回与删除 |
| `STGHeaderPanel` / `STGWorkspacePanel` | 顶栏和主面板背景、边框、内边距 |
| `Label` / `LineEdit` / `ItemList` / `TabBar` | 通用文字、输入、列表和页签 |
| `HBoxContainer` / `VBoxContainer` | 通用间距；节点局部 Separation 覆盖优先 |
| `STGMetrics` | 动态表单的 `button_height` 与 `control_height` |
| `STGStatus` | 暂停、配置错误、编辑中、测试中的状态颜色 |

例如修改保存按钮背景：选择 `STGPrimaryButton → Styles → normal`，编辑 StyleBoxFlat 的 **Bg Color**；圆角在 Corner Radius，边框在 Border Width / Border Color，内边距在 Content Margins。`hover`、`pressed`、`disabled`、`focus` 分别对应不同交互状态，修改时一起检查。

只想修改一个控件时，在该节点的 **Theme Overrides** 中覆盖颜色、字号或 StyleBox。局部覆盖优先于公共 Theme。某些状态文字和说明文字已有局部颜色，调整这些文字时也需要检查对应覆盖。

运行时会深复制主题与局部 StyleBox，按已保存的设计值计算缩放；不会回写场景、主题或累计放大尺寸。动态属性内容继承同一公共 Theme。

## 节点约定与动态内容

带 `%` 唯一名的节点是脚本查找入口。`layout.gd` 的 `STATIC_FIELDS` 列出直接绑定的主界面字段；导航、过滤器、工具按钮及 `*_slot` 也通过唯一名连接行为。**保留这些节点的名称、唯一名标记和控件类型**，可以移动到新的布局容器中。一般新增装饰、留白、外框节点无需改代码。

保留 `LibraryPanel`、`InspectorPanel` 作为专注模式隐藏的区域。`*_slot` 内运行时会装配相应画布，现有子节点只用于设计占位；不要把需要在运行时保留的按钮放进这些占位容器。`inspector` 的子内容在切换资源时重建，固定工具应放在它外面。

招式和素材属性页现已迁移到 `ui/forms/` 场景，见下一节。敌人、关卡等其他属性页仍使用动态内容；流程图、时间轴与战斗画布的内部内容由代码负责。

开发接口：场景进入独立运行后自动调用 `activate_workspace()`；插件入口在实例加入编辑器主工作区后显式调用。该方法幂等。编辑器单纯打开场景不会激活它，清理阶段也不会保存设计实例的草稿。

验收入口：`tests/ui_scene_authoring.gd` 验证资源保存、重新加载和缩放保留；`tests/ui_scene_editor.gd` 在真实编辑器验证设计模式与插件；`tests/ui_scene_capture.gd` 生成三个窗口大小与三种缩放的实际渲染图片。完整验收运行 `Run Tests.ps1`。


## 编辑招式和素材属性页（2026-10-18）

这次直接修改原项目，没有创建项目副本。以下文件在 `addons/stg_maker/ui/forms/` 中，就是运行工坊实际实例化的属性页。

| 场景 | 编辑内容 |
| --- | --- |
| `barrage_properties.tscn` | 招式类型与引用、发射节奏、弹道、拖尾长度和抛物线首阶段参数 |
| `barrage_lifecycle.tscn` | 命中规则、提前结束、后续行为与脚本命中效果的外部布局 |
| `barrage_presentation.tscn` | 发射、命中、自然结束的声音及特效 |
| `material_properties.tscn` | 子弹、激光、拖尾、区域的外观、碰撞、贴图动画与拖尾采样 |
| `material_presentation.tscn` | 普通子弹粒子和其他类型的表现说明 |

双击对应场景，切到 **2D**。设计时保留场景中保存的可见性，可临时显示条件字段方便排版；运行工坊时再按类型和参数显隐。子弹、激光、拖尾共用素材属性场景，改动共用字段会同时影响这些类型。属性页本身是纯布局，打开时不会加载游戏资产或创建预览会话。

场景默认启用了实例的「可编辑子节点」。展开分区的 `Indent → Panel → Content`，可以调整其中字段的顺序、父容器、尺寸、留白及局部主题。分区标题通过分区根节点的 **Title** 属性修改；不要直接修改脚本控制的 Heading 文字。条件字段的显隐、动态计数、资源名称和输入值由脚本更新，属于数据展示。

每个字段节点的 **Metadata → form_key** 是数据绑定标识，与节点名字、标题和当前父路径独立。调整排列或添加布局容器时，保留 `form_key`、`form_aliases`、字段内的 `form_part`，以及原控件类型。分组内部的 Heading、Caption、Indent、Panel、Content 用于折叠行为，修改共用分组结构时需保留这些内部入口。删除仍被绑定的字段会明确报出缺失键，不会偷偷恢复一套代码布局。

`components/` 保存可复用的数值、文本、下拉框、开关、颜色、XY、资源选择、按钮和折叠分组场景。修改共用组件会影响所有使用它的页面；只改一个字段时，在属性页中保存实例覆盖即可。数值范围、可选项和资源引用仍由绑定逻辑配置。

分组背景和标题样式位于 `studio_theme.tres` 的 `STGFormPanel`、`STGNestedFormPanel`、`STGFormHeading`、`STGFormTitle` 中。`STGMutedLabel` 用于说明文字。布局中的局部间距、最小尺寸和样式覆盖会按源值缩放，反复缩放不会累计放大。

扩展参数和命中效果列表放在标记为 `form_dynamic_zone` 的容器中，按实际数据实例化共用字段/分组场景。可以编辑容器的位置和这些组件的布局；不要把需要永久保留的装饰节点放进列表内容区。当前不提供完整高级弹道界面；抛物线的两种模式及其条件参数保存在招式场景中。

保存后用 `Run Studio.cmd` 打开工坊检查，或重新启用插件。属性页单独按 F6 只能看到静态布局；数据绑定与类型切换在完整工坊中验证。`tests/property_form_scenes.gd` 检查各类型绑定和保存后的布局保留；`tests/property_form_capture.gd` 保存实际渲染图片。

本次格式 13 清理以用户手动删改的页面为准。删除或移动控件时仍需同步脚本绑定；运行时不会悄悄重建被删字段。修改前文本恢复记录保存在 tests/.test_run_logs/property_cleanup_before_20261018_153833.zip，此记录不是第二份工程。
