extends SceneTree
## 属性页场景：固定控件实际参与绑定，条件显隐、保存后的布局和缩放均保留。
const Factory = preload("res://stg/definitions/definition_factory.gd")
const Form = preload("res://addons/stg_maker/ui/form_scene.gd")
const F = preload("res://addons/stg_maker/ui/fields.gd")
var checks = 0
var failures = 0
var studio
func _initialize(): run.call_deferred()
func check(ok: bool, message: String):
	checks += 1
	if not ok: failures += 1; push_error(message)
func settle():
	for frame in 5: await process_frame
func current_view() -> Control:
	return studio.inspector.get_child(0)
func keyed(root: Node, key: String):
	for node in root.find_children("*", "Control", true, false):
		if node.get_meta("form_key", "") == key: return node
	return null
func show_asset(collection: String, id: String, tab: int):
	studio.switch_collection(collection, id)
	studio.select_inspector_tab(tab)
	studio.refresh(true)
func run():
	root.size = Vector2i(1440, 1000)
	studio = load("res://addons/stg_maker/studio.tscn").instantiate()
	studio.restore_last_project = false
	studio.settings_path = "user://property_form_checks_unused.cfg"
	studio.session.recovery_folder = "user://property_form_checks/drafts"
	root.add_child(studio)
	studio.set_process(false)
	var project = STGProject.create()
	for kind in ["moving", "laser", "trail", "area"]:
		var material = Factory.bullet(kind); material.id = "material_" + kind
		project.bullets.append(material)
		var skill = Factory.trail_attack(material.id) if kind == "trail" else Factory.barrage(material.id)
		skill.id = "attack_" + kind
		project.barrages.append(skill)
	var enemy = Factory.boss(); enemy.id = "summoned_enemy"; project.bosses.append(enemy)
	var summon = Factory.barrage(""); summon.id = "attack_summon"; summon.fire_pattern.enemy_id = enemy.id
	project.barrages.append(summon)
	studio.session.project = project
	for material in project.bullets:
		for tab in 2:
			show_asset("bullets", material.id, tab); await settle()
			check(current_view().scene_file_path.ends_with("material_properties.tscn" if tab == 0 else "material_presentation.tscn"), "素材页面使用保存的场景：" + material.form)
		show_asset("bullets", material.id, 0)
		for shape in ["circle", "diamond", "rectangle", "triangle", "polygon", "ring", "sector"]:
			studio.current().visual.mode = "geometry"
			studio.current().visual.geometry.kind = shape; studio.current().collision.kind = shape
			studio.refresh(true); await settle()
			check(keyed(current_view(), "/section:外观/select:形状").is_visible_in_tree(), "形状字段来自场景：" + material.form + "/" + shape)
		studio.current().visual.mode = "texture"; studio.refresh(true); await settle()
		check(keyed(current_view(), "/section:外观/section:贴图与阶段动画").visible == (material.form in ["moving", "laser"]), "贴图动画按素材类型显隐")
	for skill in project.barrages:
		for tab in 3:
			show_asset("barrages", skill.id, tab); await settle()
			check(current_view().get_meta("form_root", false), "招式页使用保存的场景：" + skill.id + "/" + str(tab))
		show_asset("barrages", skill.id, 0); await settle()
		var view = current_view()
		check(keyed(view, "/section:发射节奏").visible == (skill.id != "attack_trail"), "拖尾专用分区保留")
		if skill.id == "attack_trail": continue
		for arrangement in ["point", "circle", "line", "path"]:
			studio.fire_pattern().arrangement = arrangement
			studio.fire_pattern().group_size = 3
			studio.refresh(true); await settle()
			check(keyed(current_view(), "/section:发射节奏/number:每组数量").visible, "分组字段存在于场景")
		for direction in ["fan", "parallel", "outward", "inward", "aim", "random"]:
			studio.fire_pattern().direction = direction; studio.refresh(true); await settle()
			check(keyed(current_view(), "/section:弹道/section:初始方向与规律旋转/select:方向分布").visible, "方向条件字段可绑定")
		if skill.id == "attack_summon": continue
		for mode in ["path", "aim", "track", "velocity", "sine", "ballistic", "orbit", "wait", "transform", "extension"]:
			studio.motion_stage().mode = mode
			studio.refresh(true); await settle()
			check(keyed(current_view(), "/section:弹道/section:高级弹道 · 飞行过程/select:飞行方式").visible, "运动参数来自场景：" + mode)
	show_asset("bullets", "material_moving", 0); await settle()
	await saved_layout()
	studio.session.recoverable_changes = false
	studio.free(); await settle()
	print("PROPERTY FORM SCENES RESULT: %d checks, %d failures" % [checks, failures])
	quit(1 if failures else 0)
func saved_layout():
	var source = Form.DIRECTORY + "material_properties.tscn"
	var hash_before = FileAccess.get_sha256(source)
	var authored = load(source).instantiate()
	var name = keyed(authored, "/text:名称")
	authored.set_editable_instance(name, true)
	Form.part(name, "caption").text = "我修改的名称标题"
	Form.part(name, "input").custom_minimum_size.y = 47
	authored.add_theme_constant_override("separation", 23)
	authored.move_child(name, authored.get_child_count() - 1)
	var packed = PackedScene.new(); packed.pack(authored)
	var path = "user://property_form_checks/saved_form.tscn"
	DirAccess.make_dir_recursive_absolute("user://property_form_checks")
	check(ResourceSaver.save(packed, path) == OK, "属性页的布局可保存")
	authored.free()
	var view = Form.open(studio, studio.inspector, path)
	var edits = [0]
	var control = F.text(view, "名称", "数据值", func(_value): edits[0] += 1)
	for scale in [150, 200, 100, 150, 100]:
		studio.set_ui_scale(scale, false); await settle()
		var unit = studio.get_meta("display_unit")
		check(Form.part(keyed(view, "/text:名称"), "caption").text == "我修改的名称标题", "自定义文字不被绑定覆盖")
		check(is_equal_approx(control.custom_minimum_size.y, 47 * unit) and view.get_theme_constant("separation") == roundi(23 * unit), "保存的尺寸与间距反复缩放后保留")
	control.text = "新值"; control.text_submitted.emit(control.text); control.focus_exited.emit()
	check(edits[0] == 1, "一次提交只触发一次修改")
	check(view.get_child(view.get_child_count() - 1).get_meta("form_key", "") == "/text:名称", "保存的字段排列顺序保留")
	check(FileAccess.get_sha256(source) == hash_before, "测试和运行没有改写正式场景")
	DirAccess.remove_absolute(path)
