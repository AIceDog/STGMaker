extends SceneTree
## Windows/OpenGL 实际渲染：所有窗口大小与缩放组合。
func _initialize(): run.call_deferred()
func run():
	root.gui_embed_subwindows = true
	var studio = load("res://addons/stg_maker/studio.tscn").instantiate()
	studio.restore_last_project = false
	studio.settings_path = "user://ui_scene_capture_unused.cfg"
	root.add_child(studio)
	studio.set_font_size(0, false)
	for size in [Vector2i(1100, 760), Vector2i(1440, 900), Vector2i(2560, 1440)]:
		root.size = size
		for scale in [100, 150, 200]:
			studio.set_ui_scale(scale, false)
			for frame in 16: await process_frame
			await RenderingServer.frame_post_draw
			root.get_texture().get_image().save_png("res://tests/ui_scene_%dx%d_%d_actual.png" % [size.x, size.y, scale])
	studio.queue_free()
	for frame in 4: await process_frame
	print("UI SCENE CAPTURE RESULT: 9 checks, 0 failures")
	quit()
