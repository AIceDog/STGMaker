extends SceneTree
var studio
var shots = 0
func _initialize(): run.call_deferred()
func shot(name: String):
	for frame in 12: await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("res://tests/property_form_" + name + "_actual.png")
	shots += 1
func run():
	root.size = Vector2i(1600, 1100)
	studio = load("res://addons/stg_maker/studio.tscn").instantiate()
	studio.restore_last_project = false
	studio.settings_path = "user://property_form_capture_unused.cfg"
	root.add_child(studio)
	studio.set_process(false)
	for kind in ["moving", "laser", "trail"]:
		var material = preload("res://stg/definitions/definition_factory.gd").bullet(kind)
		studio.session.project.bullets.append(material)
		studio.switch_collection("bullets", material.id)
		await shot(kind)
	studio.switch_collection("barrages")
	await shot("barrage")
	studio.select_inspector_tab(1); await shot("lifecycle")
	studio.select_inspector_tab(2); await shot("presentation")
	studio.set_ui_scale(150, false); await shot("scaled")
	studio.free()
	print("PROPERTY FORM CAPTURE RESULT: %d checks, 0 failures" % shots)
	quit()
