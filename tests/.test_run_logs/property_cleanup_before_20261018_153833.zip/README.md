# STGMaker · 飞行射击工坊

当前版本 **0.21.0**，唯一资产格式 **12**，使用 Godot 4.7。运行框架提供能力与生命周期，编辑器组织配置，游戏资产保存制作结果。

双击 `Run Studio.cmd` 打开工坊，`Open Editor.cmd` 打开 Godot 工程，`Run Game.cmd` 运行首个游戏。项目的本机偏好与草稿保存在独立的 STGMaker 用户目录。

- [开始制作](docs/01_authoring.md)：招式、敌人、关卡、预览和保存。
- [架构与代码入口](docs/02_architecture.md)：依赖方向、能力宿主和时序。
- [编写扩展](docs/03_extensions.md)：六种接口、参数声明和资源引用。
- [资产与导出](docs/04_assets_and_export.md)：独立文件、严格格式、构建闭包。
- [v0.20 制作职责与迁移](docs/05_v020_authoring.md)：素材、招式、敌人行为与迁移后的使用方式。
- [素材外观、碰撞与表现](docs/06_material_workbench.md)：并列素材类型、同页几何、动画粒子与位置偏移。
- [2026-10-17 设计实施状态](docs/07_authoring_design_pending.md)：分组节奏、阶段 GIF、分类招式与后续细化项。
- [亲自编辑工坊 UI](docs/08_ui_visual_editing.md)：Godot 场景布局、公共 Theme、缩放与设计模式。

内置预设、共享示例和首个游戏已转换为格式 12。当前工程只读取此格式。历史工程、历史测试与一次性转换工具保存在工程外的交付备份；本工程没有在线升级、路径重定向或历史运行分支。

运行 `Run Tests.ps1` 执行完整验收。涉及真实编辑器与界面时，测试使用隐藏的实际 Godot 窗口；错误和非零退出都会导致失败。
