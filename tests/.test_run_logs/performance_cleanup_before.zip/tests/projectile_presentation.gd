extends SceneTree
## 资源决定粒子寿命；覆盖多发射器、暂停、自然排空、保存和正式构建。
const Factory = preload("res://stg/definitions/definition_factory.gd")
const Presentation = preload("res://stg/runtime/attacks/projectile_presentation.gd")
const Contract = preload("res://stg/definitions/scene_contract.gd")
const Compiler = preload("res://addons/stg_maker/build/compiler.gd")
const Store = preload("res://addons/stg_maker/authoring/asset_store.gd")
var checks = 0
var failures = 0
func _initialize(): run.call_deferred()
func check(ok: bool, label: String):
	checks += 1
	if not ok: failures += 1; push_error(label)
func art(gpu: bool, finite: bool = true) -> PackedScene:
	var body = Node2D.new()
	for i in 2:
		var node = GPUParticles2D.new() if gpu else CPUParticles2D.new()
		node.name = "Short" if i == 0 else "Long"
		node.one_shot = finite
		node.lifetime = 0.1 if i == 0 else 0.8
		node.explosiveness = 1.0
		node.amount = 24
		node.local_coords = true
		node.use_fixed_seed = true
		node.seed = 42
		if gpu:
			var material = ParticleProcessMaterial.new()
			material.gravity = Vector3.ZERO
			material.initial_velocity_min = 20
			material.initial_velocity_max = 40
			node.process_material = material
		else:
			node.gravity = Vector2.ZERO
			node.initial_velocity_min = 20
			node.initial_velocity_max = 40
		body.add_child(node)
		node.owner = body
	var packed = PackedScene.new(); packed.pack(body); body.free()
	return packed
func fixture() -> STGProject:
	var project = STGProject.create()
	var material = Factory.bullet(); material.id = "sparks"
	project.bullets.append(material)
	var skill = Factory.barrage(material.id); skill.id = "shot"
	skill.fire_pattern.count = 1; skill.fire_pattern.rounds = 1
	skill.projectile.motion_stages[0].mode = "wait"
	skill.projectile.motion_stages[0].duration = 0.1
	project.barrages.append(skill)
	return project
func world_for(project: STGProject) -> STGSimulation:
	var world = STGSimulation.new(); root.add_child(world)
	world.reset(project, "barrages", "shot"); world.player = Vector2(9000, 9000)
	check(world.issue.is_empty(), "粒子配置通过正式运行校验：" + world.issue)
	return world
func run():
	check(STGProject.VERSION == 13, "当前格式为13")
	for property in ["scene", "visual_scene", "visual_animation", "show_base_visual", "particle_duration", "beam_path", "beam_path_size"]:
		check(not Factory.bullet().get_property_list().any(func(item): return item.name == property), "素材已删除字段：" + property)
	for property in ["warning", "fade"]:
		check(not STGAttackLifecycle.new().get_property_list().any(func(item): return item.name == property), "生命周期已删除字段：" + property)
	for property in ["at", "extension", "extension_duration"]:
		check(not STGFirePattern.new().get_property_list().any(func(item): return item.name == property), "发射已删除字段：" + property)
	for gpu in [false, true]:
		var scene = art(gpu)
		check(Contract.particles_issue(scene, true).is_empty(), "CPU/GPU一次性场景合法")
		var a = Presentation.new(); root.add_child(a); a.configure(scene)
		var b = Presentation.new(); root.add_child(b); b.configure(scene)
		a.tick(0.2)
		check(a.particles[0].done and not a.particles[1].done and not a.is_finished(), "短发射器结束后等待长发射器")
		check(b.particles[0].age == 0, "共享资源的实例时钟独立")
		var age = a.particles[1].age
		for i in 4: await process_frame
		check(a.particles[1].age == age, "不推进模拟时钟时粒子暂停")
		b.tick(0.8); a.tick(0.6)
		check(a.is_finished() and b.is_finished(), "多次步进与一次快进的完成结果一致")
		a.free(); b.free()
		var project = fixture(); var material = project.bullets[0]
		material.spawn_particles = scene; material.hit_particles = scene
		var compiled = Compiler.compile_library(project, [{"collection": "barrages", "id": "shot"}])
		check(compiled.issue.is_empty() and compiled.library.bullets[0].spawn_particles == scene, "编译保留粒子资源依赖")
		var path = "user://natural_particles_%d/library.tres" % Time.get_ticks_usec()
		check(Store.save_library(project, path).is_empty(), "粒子资源可事务保存")
		var restored: STGProject = ResourceLoader.load(path, "", ResourceLoader.CACHE_MODE_IGNORE)
		check(restored != null and restored.validate().is_empty(), "粒子保存重开合法")
		var world = world_for(project); world.step(0)
		check(world.effects.size() == 1, "发射粒子在事件位置生成")
		world.step(0.2)
		check(world.actors.is_empty() and world.effects.size() == 1 and not world.completed, "弹体结束不会提前销毁发射粒子")
		world.step(0.6)
		check(world.effects.is_empty() and world.completed, "所有发射粒子完成后释放实例")
		world.free()
		material.spawn_particles = null; material.run_particles = art(gpu, false)
		world = world_for(project); world.step(0.01)
		var actor = world.actors[0]; var running = actor.particle_presentation
		actor.stop(); world.step(0.01)
		check(is_instance_valid(running) and running.get_parent() == world and running.draining, "弹体结束后运行粒子脱离并排空")
		check(running.particles.all(func(entry): return not entry.node.emitting), "脱离后不再产生新粒子")
		world.step(0.9)
		check(world.effects.is_empty(), "运行粒子按资源自身寿命消散")
		world.free()
		material.spawn_particles = scene; material.run_particles = null
		world = world_for(project); world.step(0); world.clear_attacks()
		check(world.effects.is_empty() and world.actors.is_empty(), "强制清屏立即清理所有粒子")
		world.free()
		check(not Contract.particles_issue(art(gpu, false), true).is_empty(), "事件连续发射配置被拒绝")
		check(Contract.particles_issue(art(gpu, false), false).is_empty(), "运行粒子允许持续发射")
	var invalid = fixture()
	invalid.bullets[0].spawn_particles = art(false, false)
	var diagnostics = preload("res://stg/definitions/validation.gd").diagnostics(invalid)
	check(diagnostics.any(func(item): return item.get("collection", "") == "bullets" and item.get("field", "") == "spawn_particles" and item.message.contains("One Shot")), "无法结束的粒子定位到具体素材字段和场景节点")
	var stalled = art(false).instantiate()
	var animator = AnimationPlayer.new()
	animator.name = "StalledAnimation"
	var clips = AnimationLibrary.new()
	var clip = Animation.new(); clip.length = 1
	clips.add_animation("effect", clip)
	animator.add_animation_library("", clips)
	animator.autoplay = "effect"; animator.speed_scale = 0
	stalled.add_child(animator); animator.owner = stalled
	var stalled_scene = PackedScene.new(); stalled_scene.pack(stalled); stalled.free()
	check(Contract.particles_issue(stalled_scene, true).contains("动画速度"), "速度为零且无法结束的粒子动画被拒绝")
	await render_clock()
	await exported()
	print("PROJECTILE PRESENTATION RESULT: %d checks, %d failures" % [checks, failures])
	quit(1 if failures else 0)
func render_clock():
	if DisplayServer.get_name() == "headless": return
	var presentation = Presentation.new(); root.add_child(presentation)
	presentation.position = Vector2(180, 160); presentation.configure(art(true, false))
	for i in 20: presentation.tick(1.0 / 120)
	for i in 3: await process_frame
	await RenderingServer.frame_post_draw
	var paused = root.get_texture().get_image().get_data()
	for i in 5: await process_frame
	await RenderingServer.frame_post_draw
	check(root.get_texture().get_image().get_data() == paused, "真实GPU粒子暂停保持画面")
	for i in 20: presentation.tick(1.0 / 120)
	for i in 3: await process_frame
	await RenderingServer.frame_post_draw
	check(root.get_texture().get_image().get_data() != paused, "多个固定步长在同一渲染帧累计推进")
	presentation.free()
func exported():
	var game = preload("res://tests/game_fixture.gd").create()
	game.library.bullets[0].spawn_particles = load("res://examples/presentation/impact_sparks.tscn")
	game.library.bosses[0].phases[0].behavior_flow = Factory.flow([Factory.action("fire", game.library.barrages[0].id)])
	var output = "user://natural_particles_export_%d" % Time.get_ticks_usec()
	var builder = preload("res://addons/stg_maker/build/project_builder.gd")
	var built = builder.build(game, output)
	check(built.issue.is_empty(), "粒子独立游戏可构建：" + built.issue)
	if not built.issue.is_empty(): return
	check(FileAccess.file_exists(output.path_join("examples/presentation/impact_sparks.tscn")) and FileAccess.file_exists(output.path_join("examples/presentation/spark.svg")), "粒子场景和贴图依赖进入独立工程")
	var log: Array = []; var runner = preload("res://tests/export_runtime.gd")
	var code = runner.import_project(built.path, log)
	check(code == 0 and not builder._has_errors(log), "带粒子的全新工程可冷导入：" + "\n".join(log))
	log.clear(); code = runner.run(built.path, log)
	check(code == 0 and not builder._has_errors(log), "带粒子的独立工程可实际启动：" + "\n".join(log))
