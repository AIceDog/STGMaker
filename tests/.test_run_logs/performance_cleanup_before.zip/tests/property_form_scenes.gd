extends SceneTree
## 属性页场景：固定控件实际参与绑定，条件显隐、保存后的布局和缩放均保留。
const Factory = preload("res://stg/definitions/definition_factory.gd")
const Form = preload("res://addons/stg_maker/ui/form_scene.gd")
const F = preload("res://addons/stg_maker/ui/fields.gd")
var checks = 0
var failures = 0
var studio
func _initialize(): run.call_deferred()
func check(ok: bool, message: String):
	checks += 1
	if not ok: failures += 1; push_error(message)
func settle():
	for frame in 5: await process_frame
func current_view() -> Control:
	return studio.inspector.get_child(0)
func keyed(root: Node, key: String):
	for node in root.find_children("*", "Control", true, false):
		if node.get_meta("form_key", "") == key: return node
	return null
func show_asset(collection: String, id: String, tab: int):
	studio.switch_collection(collection, id)
	studio.select_inspector_tab(tab)
	studio.refresh(true)
func run():
	root.size = Vector2i(1440, 1000)
	studio = load("res://addons/stg_maker/studio.tscn").instantiate()
	studio.restore_last_project = false
	studio.settings_path = "user://property_form_checks_unused.cfg"
	studio.session.recovery_folder = "user://property_form_checks/drafts"
	root.add_child(studio)
	studio.set_process(false)
	var project = STGProject.create()
	for kind in ["moving", "laser", "trail", "area"]:
		var material = Factory.bullet(kind); material.id = "material_" + kind
		project.bullets.append(material)
		var skill = Factory.trail_attack(material.id) if kind == "trail" else Factory.barrage(material.id)
		skill.id = "attack_" + kind
		project.barrages.append(skill)
	var enemy = Factory.boss(); enemy.id = "summoned_enemy"; project.bosses.append(enemy)
	var summon = Factory.barrage(""); summon.id = "attack_summon"; summon.fire_pattern.enemy_id = enemy.id
	project.barrages.append(summon)
	studio.session.project = project
	for material in project.bullets:
		for tab in 2:
			show_asset("bullets", material.id, tab); await settle()
			check(current_view().scene_file_path.ends_with("material_properties.tscn" if tab == 0 else "material_presentation.tscn"), "素材页面使用保存的场景：" + material.form)
		show_asset("bullets", material.id, 0)
		for shape in ["circle", "diamond", "rectangle", "triangle", "polygon", "ring", "sector"]:
			studio.current().visual.mode = "geometry"
			studio.current().visual.geometry.kind = shape; studio.current().collision.kind = shape
			studio.refresh(true); await settle()
			check(keyed(current_view(), "/section:外观/select:形状").is_visible_in_tree(), "形状字段来自场景：" + material.form + "/" + shape)
		studio.current().visual.mode = "texture"; studio.refresh(true); await settle()
		check(keyed(current_view(), "/section:外观/section:贴图与阶段动画").visible == (material.form in ["moving", "laser"]), "贴图动画按素材类型显隐")
	for skill in project.barrages:
		for tab in 3:
			show_asset("barrages", skill.id, tab); await settle()
			check(current_view().get_meta("form_root", false), "招式页使用保存的场景：" + skill.id + "/" + str(tab))
		show_asset("barrages", skill.id, 0); await settle()
		var view = current_view()
		check(keyed(view, "/section:发射节奏").visible == (skill.id != "attack_trail"), "拖尾专用分区保留")
		if skill.id == "attack_trail": continue
		for arrangement in ["point", "circle", "line", "path"]:
			studio.fire_pattern().arrangement = arrangement
			studio.fire_pattern().group_size = 3
			studio.refresh(true); await settle()
			check(keyed(current_view(), "/section:发射节奏/number:每组数量").visible, "分组字段存在于场景")
		for direction in ["fan", "parallel", "outward", "inward", "aim", "random"]:
			studio.fire_pattern().direction = direction; studio.refresh(true); await settle()
			check(keyed(current_view(), "/section:弹道/section:初始方向与规律旋转/select:方向分布").visible, "方向条件字段可绑定")
		if skill.id == "attack_summon": continue
		for mode in ["path", "aim", "track", "velocity", "sine", "ballistic", "orbit", "wait", "transform", "extension"]:
			studio.motion_stage().mode = mode
			studio.refresh(true); await settle()
			check(keyed(current_view(), "/section:弹道/section:初始方向与规律旋转/section:抛物线参数").visible == (mode == "ballistic"), "仅抛物线显示简化参数：" + mode)
	show_asset("bullets", "material_moving", 0); await settle()
	await parabola_controls()
	await saved_layout()
	studio.session.recoverable_changes = false
	studio.free(); await settle()
	print("PROPERTY FORM SCENES RESULT: %d checks, %d failures" % [checks, failures])
	quit(1 if failures else 0)
func saved_layout():
	var source = Form.DIRECTORY + "material_properties.tscn"
	var hash_before = FileAccess.get_sha256(source)
	var authored = load(source).instantiate()
	var name = keyed(authored, "/text:名称")
	authored.set_editable_instance(name, true)
	Form.part(name, "caption").text = "我修改的名称标题"
	Form.part(name, "input").custom_minimum_size.y = 47
	authored.add_theme_constant_override("separation", 23)
	authored.move_child(name, authored.get_child_count() - 1)
	var packed = PackedScene.new(); packed.pack(authored)
	var path = "user://property_form_checks/saved_form.tscn"
	DirAccess.make_dir_recursive_absolute("user://property_form_checks")
	check(ResourceSaver.save(packed, path) == OK, "属性页的布局可保存")
	authored.free()
	var view = Form.open(studio, studio.inspector, path)
	var edits = [0]
	var control = F.text(view, "名称", "数据值", func(_value): edits[0] += 1)
	for scale in [150, 200, 100, 150, 100]:
		studio.set_ui_scale(scale, false); await settle()
		var unit = studio.get_meta("display_unit")
		check(Form.part(keyed(view, "/text:名称"), "caption").text == "我修改的名称标题", "自定义文字不被绑定覆盖")
		check(is_equal_approx(control.custom_minimum_size.y, 47 * unit) and view.get_theme_constant("separation") == roundi(23 * unit), "保存的尺寸与间距反复缩放后保留")
	control.text = "新值"; control.text_submitted.emit(control.text); control.focus_exited.emit()
	check(edits[0] == 1, "一次提交只触发一次修改")
	check(view.get_child(view.get_child_count() - 1).get_meta("form_key", "") == "/text:名称", "保存的字段排列顺序保留")
	check(FileAccess.get_sha256(source) == hash_before, "测试和运行没有改写正式场景")
	DirAccess.remove_absolute(path)

func choose_field(key: String, text: String) -> bool:
	var item = keyed(current_view(), key)
	if item == null: return false
	var selector = Form.part(item, "input")
	for i in selector.item_count:
		if selector.get_item_text(i) == text:
			selector.select(i); selector.item_selected.emit(i); return true
	return false
func parabola_controls():
	show_asset("barrages", "attack_moving", 0); await settle()
	var stages = studio.current().projectile.motion_stages
	stages.assign([Factory.stage("velocity"), Factory.stage("wait")])
	stages[0].speed = 123; stages[0].duration = 3; stages[1].duration = 4
	studio.refresh(true); await settle()
	var key = "/section:弹道/section:初始方向与规律旋转/select:方向分布"
	var scope = "/section:弹道/section:初始方向与规律旋转/section:抛物线参数"
	check(choose_field(key, "抛物线飞行"), "方向分布可选择抛物线")
	await settle()
	check(studio.current().projectile.motion_stages[0].mode == "ballistic" and studio.current().projectile.motion_stages.size() == 2, "选择抛物线只修改首阶段")
	check(studio.current().projectile.motion_stages[1].duration == 4 and studio.current().projectile.motion_stages[0].speed == 123, "后续阶段及其他参数保留")
	check(keyed(current_view(), scope).visible and keyed(current_view(), scope + "/number:飞抵目标时间 s（0 自动）").visible, "瞄准模式显示飞行时间")
	check(choose_field(scope + "/select:抛射方式", "固定初速度"), "抛物线支持固定初速度")
	await settle()
	check(not studio.current().projectile.motion_stages[0].ballistic_aim and keyed(current_view(), scope + "/vector:世界坐标初速度 px/s").visible, "固定模式显示世界坐标初速度")
	studio.undo_edit(); await settle()
	check(studio.current().projectile.motion_stages[0].ballistic_aim, "抛射方式切换可撤销")
	studio.redo_edit(); await settle()
	check(not studio.current().projectile.motion_stages[0].ballistic_aim, "抛射方式切换可重做")
	check(choose_field(key, "平行"), "抛物线可切回普通方向")
	await settle()
	check(studio.current().projectile.motion_stages[0].mode == "velocity" and studio.fire_pattern().direction == "parallel", "切回普通方向后首阶段沿发射方向直飞")
	studio.undo_edit(); await settle()
	check(studio.current().projectile.motion_stages[0].mode == "ballistic" and not studio.current().projectile.motion_stages[0].ballistic_aim, "撤销恢复完整抛物线配置")
	var path = "user://property_parabola_%d/library.tres" % Time.get_ticks_usec()
	check(preload("res://addons/stg_maker/authoring/asset_store.gd").save_library(studio.session.project, path).is_empty(), "抛物线通过正式保存路径落盘")
	var loaded = ResourceLoader.load(path, "", ResourceLoader.CACHE_MODE_IGNORE)
	var restored = loaded.find("barrages", "attack_moving")
	check(restored.projectile.motion_stages[0].mode == "ballistic" and restored.projectile.motion_stages[1].duration == 4, "保存重开保留抛物线和后续阶段")
	show_asset("bullets", "material_moving", 0); await settle()
