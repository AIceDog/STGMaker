@tool
extends STGBehaviorProgram
var seconds: float
func start(ctx: STGBehaviorContext, p: Dictionary) -> void:
    seconds = p.seconds
    if seconds <= 0: ctx.complete()
func tick(ctx: STGBehaviorContext, dt: float) -> void:
    if ctx.elapsed()+0.000001 >= seconds: ctx.complete("completed", maxf(0, ctx.elapsed()-seconds))
