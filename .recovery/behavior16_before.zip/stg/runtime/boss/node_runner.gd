@tool
extends RefCounted
## 全部行为节点共用宿主；不按程序 ID / 类型执行任何节点算法。
const Session=preload("res://stg/runtime/extensions/extension_session.gd")
const Adapter=preload("res://stg/runtime/boss/behavior_adapter.gd")
var session=Session.new()
var adapter
var node:STGFlowNode
var behavior
var parameters:Dictionary
var context:STGBehaviorContext
var stage:String="windup"
var stage_elapsed:float=0
var finished:bool=false
var failed:bool=false
var output_id:String="completed"
var remaining:float=0
var _animation_owned:bool=false
var _movement_owned:bool=false
var _hit_serial:int=0
var _restore_visible:bool=true
var _restore_invulnerable:bool=false
func start(value:STGFlowNode, data, flow:STGBehaviorFlow, tasks:Array) -> void:
    node=value;behavior=data
    if node.behavior_preset==null:
        _error("节点缺少行为预设与程序声明");return
    var errors=node.behavior_preset.validate(node.program_parameters)
    if not errors.is_empty():_error("；".join(errors));return
    parameters=node.parameters()
    _hit_serial=behavior.world.boss_hit_serial
    adapter=Adapter.new();adapter.configure(node,behavior,flow,tasks)
    _restore_visible=behavior.world.boss_visible
    _restore_invulnerable=behavior.world.boss_invulnerable
    behavior.active_node_id=node.id;behavior.action_running=true
    _enter("windup")
func tick(dt:float) -> bool:
    remaining=dt
    if finished:return true
    if parameters.get("interrupt_on_hit",false) and behavior.world.boss_hit_serial!=_hit_serial:
        cancel("interrupted");remaining=0;return true
    for transition in 4:
        if stage in ["windup","recovery"]:
            var duration:float=parameters[stage]
            var consumed=minf(remaining,maxf(0,duration-stage_elapsed))
            stage_elapsed+=consumed;remaining-=consumed
            _animate(consumed)
            if stage_elapsed+0.000001<duration:return false
            if stage=="recovery":_finish();return true
            if not _begin_active():return true
        if stage=="active":
            if not session.finished and remaining>0:
                var budget=remaining
                adapter.step_budget=budget
                session.tick(budget)
                var consumed=budget-clampf(context.remaining_seconds,0,budget) if session.finished else budget
                _animate(consumed)
                remaining=budget-consumed
            if not session.finished:return false
            failed=session.failed
            output_id=context.output_id
            if failed:output_id="failure"
            var ids=node.ports().map(func(port):return port.id)
            if output_id not in ids:_error("节点返回未声明出口："+output_id);return true
            _release_movement()
            _enter("recovery")
    return finished
func _begin_active() -> bool:
    var definition=node.behavior_preset.program
    if "movement" in definition.capabilities:
        var control:Dictionary=behavior.world.behavior_control
        if int(control.movement)!=0:_error("同一敌人存在并行位移争用");return false
        control.movement=get_instance_id();_movement_owned=true
    _enter("active")
    if finished:return false
    context=STGBehaviorContext.new()
    context._dispatch=adapter.command;context._query=adapter.query
    adapter.movement_token=get_instance_id() if _movement_owned else 0
    adapter.step_budget=remaining
    if not session.begin(definition,parameters,"behavior",context):_error(session.issue);return false
    return true
func _enter(value:String) -> void:
    _release_animation()
    stage=value;stage_elapsed=0
    behavior.action_state={"windup":"前摇","active":"执行","recovery":"后摇"}[value]
    var name:String=parameters.get(value+"_animation","")
    if not behavior.animation_allowed or name.is_empty() or (value=="active" and not node.children.is_empty()):return
    var control:Dictionary=behavior.world.behavior_control
    if int(control.animation) not in [0,get_instance_id()]:_error("同一敌人存在身体动画争用");return
    control.animation=get_instance_id();_animation_owned=true
    behavior.world.boss_presentation.enter(name,float(parameters.get(value,0)),value!="active")
func _animate(dt:float) -> void:
    if _animation_owned and int(behavior.world.behavior_control.animation)==get_instance_id():
        behavior.world.boss_presentation.tick(dt)
func _release_movement() -> void:
    if not _movement_owned:return
    if int(behavior.world.behavior_control.movement)==get_instance_id():behavior.world.behavior_control.movement=0
    behavior.world.boss_visible=_restore_visible
    behavior.world.boss_invulnerable=_restore_invulnerable
    _movement_owned=false
func _release_animation() -> void:
    if not _animation_owned:return
    if int(behavior.world.behavior_control.animation)==get_instance_id():
        behavior.world.behavior_control.animation=0
        behavior.world.boss_presentation.reset()
    _animation_owned=false
func _finish() -> void:
    if finished:return
    finished=true
    _release_movement();_release_animation()
    behavior.world.action_completed_at[node.id]=behavior.world.time
    behavior.world.boss_action_event.emit(node.id,"completed" if not failed else "failed")
    behavior.action_running=false;behavior.active_node_id=""
func _error(message:String) -> void:
    failed=true;output_id="failure"
    behavior.world.issue=node.title+"："+message
    session.cancel("failed",true)
    if adapter!=null:adapter.cancel()
    _finish()
func cancel(reason:String="stopped") -> void:
    if finished:return
    session.cancel(reason)
    if adapter!=null:adapter.cancel()
    _release_movement();_release_animation()
    finished=true;failed=true;output_id="failure"
    behavior.action_running=false;behavior.active_node_id=""
    behavior.world.boss_action_event.emit(node.id,"cancelled")
func rebase(displacement:Vector2) -> void:
    if session.implementation!=null:session.implementation.rebase(displacement)
