@tool
class_name STGBehaviorProgram
extends STGExtension
## 所有行为程序唯一契约；瞬时节点可在 start 中完成。参数不得保存运行状态。
func start(_context: STGBehaviorContext, _parameters: Dictionary) -> void: pass
func tick(_context: STGBehaviorContext, _dt: float) -> void: pass
func rebase(_displacement: Vector2) -> void: pass
