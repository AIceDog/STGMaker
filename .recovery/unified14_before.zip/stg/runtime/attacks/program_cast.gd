@tool
extends RefCounted
## 与旧发射计划提供相同完成/归属接口；程序和实体会话均复用 extension_session。
const Session = preload("res://stg/runtime/extensions/extension_session.gd")
const Entity = preload("res://stg/runtime/attacks/program_entity.gd")
const Trail = preload("res://stg/runtime/attacks/program_trail.gd")
const Copy = preload("res://stg/definitions/config_copy.gd")
const Factory = preload("res://stg/definitions/definition_factory.gd")
var world
var prefab: STGBarrageSkill
var owner_id: int
var origin: Vector2:
	set(value):
		origin = value
		if context != null: context._origin = value
var heading: float
var elapsed: float = 0
var first_step_duration: float = -1
var cancelled: bool = false
var failed: bool = false
var session = Session.new()
var context: STGAttackContext
var entities: Dictionary = {}
var _ticket: int = 0
var _started: bool = false
var _commands: int = 0
var _command_time: float = -1
var _step: float = 0
var _spawn_sound_played: bool = false
var _seed: int
func start(definition: STGBarrageSkill, at: Vector2, owner: int, angle: float = 0, _target: Vector2 = Vector2.ZERO) -> void:
	prefab = definition; origin = at; owner_id = owner; heading = angle
	_seed = world.rng.randi()
func tick(_world, dt: float) -> void:
	if cancelled: return
	if first_step_duration >= 0: dt = minf(dt, first_step_duration); first_step_duration = -1
	_step = dt; _commands = 0
	elapsed += dt
	if not _started:
		_started = true
		context = STGAttackContext.new()
		context._origin = origin; context._initial_origin = origin; context._heading = heading; context._random.seed = _seed
		context._dispatch = command; context._query = query
		if not session.begin(prefab.attack_preset.program, prefab.attack_preset.parameters(prefab.program_parameters), "attack", context): _fail(session.issue); return
	if not session.finished: session.tick(dt)
	if session.failed: _fail("攻击程序报告失败")
	for ticket in entities.keys():
		if not is_instance_valid(entities[ticket]) or not entities[ticket].alive: entities.erase(ticket)
func _fail(text: String):
	failed = true
	for actor in entities.values():
		if is_instance_valid(actor): actor.stop()
	world.issue = prefab.title + "：" + text
	cancel("failed")
	return null
func _actor(handle):
	if not handle is STGAttackHandle or handle._battle != world.attack_epoch or handle._execution != get_instance_id(): return null
	var actor = entities.get(handle._ticket)
	return actor if is_instance_valid(actor) and actor.alive else null
func query(key: String, handle):
	if key == "target": return world.player
	if key == "owner_position": return world.boss
	if key == "health": return world.hp
	if key == "time": return world.time
	if key == "owner_id": return owner_id
	if key == "damage": return prefab.attack_preset.lifecycle.damage
	if key == "seconds_since_hit": return world.time-world.boss_last_hit_at
	if key == "action_elapsed": return world.time-world.action_completed_at.get(str(handle),-1000000.0)
	var actor = _actor(handle)
	if key == "valid": return actor != null
	if key == "position": return actor.program_position() if actor != null else Vector2.ZERO
	if key == "velocity": return actor.velocity if actor != null else Vector2.ZERO
	return null
func command(key: String, data: Dictionary):
	if cancelled: return null
	return _execute(key, data)
func entity_command(key: String, data: Dictionary, own_handle: STGAttackHandle):
	if key not in ["transform","velocity","destroy"] or data.get("handle") != own_handle or _actor(own_handle)==null: return false
	return _execute(key,data)
func _execute(key: String, data: Dictionary):
	if _command_time != world.time: _command_time = world.time; _commands = 0
	_commands += 1
	if _commands > 4096: return _fail("单步程序命令超过4096次")
	for field in ["position","velocity"]:
		if data.has(field) and (not data[field] is Vector2 or not data[field].is_finite() or data[field].length()>1000000): return _fail("非有限坐标："+field)
	if data.has("rotation") and not is_finite(data.rotation): return _fail("非有限角度")
	if data.has("width") and (not is_finite(data.width) or data.width<=0 or data.width>4096): return _fail("宽度必须为0–4096之间的有限正数")
	if data.has("points"):
		if data.points.size()<2 or data.points.size()>512: return _fail("折线必须有2–512个点")
		for point in data.points:
			if not point.is_finite() or point.length()>1000000: return _fail("折线包含非有限坐标")
	if key == "create": return _create(data)
	if key == "present":
		var life = prefab.attack_preset.lifecycle
		var event = str(data.get("event",""))
		if event not in ["spawn","hit","expire"]: return _fail("表现事件仅支持spawn/hit/expire")
		world.present_program_event(life,event,data.position,heading)
		return true
	var actor = _actor(data.get("handle"))
	if actor == null: return false
	match key:
		"transform": actor.program_set_transform(data.position, data.rotation)
		"velocity": actor.velocity = data.velocity
		"points":
			if not actor is Entity or actor.capability not in ["Beam2D","Polyline2D"]: return false
			actor.points = data.points.duplicate()
			if actor.capability=="Beam2D": actor.rotation=(actor.points[-1]-actor.points[0]).angle()
		"width":
			if actor is Entity and actor.capability in ["Body2D","Area2D"]: return false
			actor.program_set_width(data.width)
		"active": actor.damaging = data.enabled
		"destroy": actor.stop()
		_: return false
	return true
func _create(data: Dictionary) -> STGAttackHandle:
	if entities.size()>=256 or world.actors.size()>=world.MAX_ACTORS: _fail("程序实体数量超过上限"); return null
	var seconds: float = data.get("lifetime",0)
	if not is_finite(seconds) or seconds<=0 or seconds>60: _fail("实体寿命必须为0–60秒的有限正数"); return null
	var preset = prefab.attack_preset
	var material_id = preset.material_id if prefab.material_override.is_empty() else prefab.material_override
	var material: STGBulletDefinition = world.project.find("bullets",material_id)
	var capability: String = data.capability
	if material == null or capability not in material.supported_capabilities(): _fail("素材不支持 "+capability); return null
	if capability not in ["Body2D","Trail2D","Area2D"] and not data.has("points"): _fail("缺少线段几何"); return null
	var segment: float = data.get("segment_seconds",1.0)
	if not is_finite(segment) or segment<=0 or segment>60: _fail("拖尾段寿命无效"); return null
	var config = STGProjectileDefinition.new()
	config.bullet_id = material_id; config.lifecycle = Copy.copy(preset.lifecycle)
	config.motion_stages.assign([Factory.stage("wait")]); config.motion_stages[0].duration = segment if capability=="Trail2D" else seconds
	var actor = Trail.new() if capability=="Trail2D" else Entity.new()
	actor.setup(Copy.copy(material),config,data.get("position",origin),heading,owner_id)
	actor.lifetime = seconds; actor.velocity = data.get("velocity",Vector2.ZERO)
	actor.first_step_duration = _step
	if actor is Trail: actor.driver_position = data.get("position",origin)
	else:
		actor.capability = capability
		actor.points = data.get("points",PackedVector2Array()).duplicate()
		if capability=="Beam2D": actor.rotation=(actor.points[-1]-actor.points[0]).angle()
	if data.has("width"): actor.program_set_width(data.width)
	actor.set_meta("source_skill",prefab.id)
	world.add_child(actor); actor.configure_presentation(); world.actors.append(actor)
	_ticket += 1
	entities[_ticket] = actor
	var handle = STGAttackHandle.new()
	handle._battle = world.attack_epoch; handle._execution = get_instance_id(); handle._ticket = _ticket
	if data.get("entity_program") != null:
		var binding: STGExtensionBinding = data.entity_program
		var entity_context = STGAttackEntityContext.new()
		entity_context._handle = handle; entity_context._dispatch = entity_command.bind(handle); entity_context._query = query; entity_context._random.seed = hash([_seed,_ticket])
		actor.entity_session = Session.new()
		if not actor.entity_session.begin(binding.definition,binding.parameters,"entity",entity_context): _fail(actor.entity_session.issue)
	world.present_program_event(config.lifecycle,"spawn",data.get("position",origin),heading,not _spawn_sound_played)
	_spawn_sound_played = true
	if capability=="Body2D": world.present_material_particles(material.spawn_particles,data.get("position",origin),heading)
	return handle
func emission_finished() -> bool: return cancelled or _started and session.finished
func is_finished(_world) -> bool: return emission_finished() and world.count_owned(owner_id,false)==0
func cancel(reason: String = "stopped") -> void:
	if cancelled: return
	cancelled = true
	session.cancel(reason)
	if reason in ["failed","invalid","removed"]:
		for actor in entities.values():
			if is_instance_valid(actor): actor.stop()
