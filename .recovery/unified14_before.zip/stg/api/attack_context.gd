@tool
class_name STGAttackContext
extends STGExtensionContext
## 战斗世界坐标、弧度、秒。命令通过受控适配器，不传递 Simulation 引用。
var _dispatch: Callable
var _query: Callable
var _initial_origin: Vector2
var _origin: Vector2
var _heading: float
var _random = RandomNumberGenerator.new()
func origin() -> Vector2: return _origin
func initial_origin() -> Vector2: return _initial_origin
func owner_id() -> int: return _query.call("owner_id",null) if _active else 0
func damage() -> float: return _query.call("damage",null) if _active else 0.0
func seconds_since_hit() -> float: return _query.call("seconds_since_hit",null) if _active else 0.0
func action_elapsed(identifier: String) -> float: return _query.call("action_elapsed",identifier) if _active else 0.0
func heading() -> float: return _heading
func target_position() -> Vector2: return _query.call("target", null) if _active else Vector2.ZERO
func player_position() -> Vector2: return target_position()
func enemy_position() -> Vector2: return _query.call("owner_position", null) if _active else Vector2.ZERO
func enemy_health() -> float: return _query.call("health", null) if _active else 0.0
func time_seconds() -> float: return _query.call("time", null) if _active else 0.0
func random_range(minimum: float, maximum: float) -> float: return _random.randf_range(minimum, maximum) if _active else minimum
func random_integer(minimum: int, maximum: int) -> int: return _random.randi_range(minimum, maximum) if _active else minimum
func _send(command: String, data: Dictionary): return _dispatch.call(command, data) if _active and _dispatch.is_valid() else null
func spawn_body(at: Vector2, velocity: Vector2, seconds: float, entity_program: STGExtensionBinding = null) -> STGAttackHandle:
	return _send("create", {"capability":"Body2D", "position":at, "velocity":velocity, "lifetime":seconds, "entity_program":entity_program})
func create_beam(a: Vector2, b: Vector2, width: float, seconds: float) -> STGAttackHandle:
	return _send("create", {"capability":"Beam2D", "position":a, "points":PackedVector2Array([a,b]), "width":width, "lifetime":seconds})
func create_polyline(points: PackedVector2Array, width: float, seconds: float) -> STGAttackHandle:
	return _send("create", {"capability":"Polyline2D", "points":points, "width":width, "lifetime":seconds})
func create_trail(at: Vector2, width: float, seconds: float, segment_seconds: float) -> STGAttackHandle:
	return _send("create", {"capability":"Trail2D", "position":at, "width":width, "lifetime":seconds, "segment_seconds":segment_seconds})
func create_area(at: Vector2, seconds: float) -> STGAttackHandle:
	return _send("create", {"capability":"Area2D", "position":at, "lifetime":seconds})
func set_transform(handle: STGAttackHandle, at: Vector2, angle: float = 0) -> bool:
	return _send("transform", {"handle":handle,"position":at,"rotation":angle}) == true
func set_velocity(handle: STGAttackHandle, velocity: Vector2) -> bool:
	return _send("velocity", {"handle":handle,"velocity":velocity}) == true
func set_points(handle: STGAttackHandle, points: PackedVector2Array) -> bool:
	return _send("points", {"handle":handle,"points":points}) == true
func set_width(handle: STGAttackHandle, width: float) -> bool:
	return _send("width", {"handle":handle,"width":width}) == true
func set_active(handle: STGAttackHandle, enabled: bool) -> bool:
	return _send("active", {"handle":handle,"enabled":enabled}) == true
func destroy(handle: STGAttackHandle) -> bool: return _send("destroy", {"handle":handle}) == true
func valid(handle: STGAttackHandle) -> bool: return _query.call("valid", handle) if _active else false
func present(event: String, at: Vector2) -> void: _send("present", {"event":event,"position":at})
func _close() -> void:
	super._close()
	_dispatch = Callable()
	_query = Callable()
