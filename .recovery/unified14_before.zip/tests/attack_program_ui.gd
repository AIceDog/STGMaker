extends SceneTree
var checks=0
var failures=0
var studio
func _initialize():run.call_deferred()
func check(ok:bool,message:String):
 checks+=1
 if not ok:failures+=1;push_error(message)
func frames(n=4):
 for i in n:await process_frame
func parameter(root:Node,key:String):
 for node in root.find_children("*","Control",true,false):
  if node.get_meta("program_parameter","")==key:return node
 return null
func run():
 root.size=Vector2i(1440,900);root.gui_embed_subwindows=true
 studio=load("res://addons/stg_maker/studio.tscn").instantiate()
 studio.restore_last_project=false;studio.settings_path="user://attack_program_ui.cfg";studio.show_trajectories=false
 root.add_child(studio);studio.set_ui_scale(100,false)
 await frames()
 var popup=studio.create_button.get_popup()
 check(popup.get_item_index(10000)>=0,"从模板新建提供预设制作入口")
 popup.id_pressed.emit(10000);await frames()
 var maker=studio.attack_preset_editor
 check(is_instance_valid(maker) and maker.visible and maker.view.scene_file_path.ends_with("attack_preset_editor.tscn"),"预设制作使用静态可编辑场景")
 check(maker.current()!=null and maker.current().program!=null,"初始参考预设可编辑")
 var speed=parameter(maker.view,"speed")
 check(speed is SpinBox,"程序元数据生成默认值控件")
 if speed is SpinBox:
  var identity=speed.get_instance_id()
  speed.value=330
  await frames()
  check(maker.current().default_parameters.speed==330 and parameter(maker.view,"speed").get_instance_id()==identity,"默认值编辑复用控件并进入资产事务")
 maker._option("speed","min",350.0);await frames()
 check(not maker.current().validate(studio.session.project).is_empty() and parameter(maker.view,"speed") is SpinBox,"调整开放范围后仍可修正默认值")
 parameter(maker.view,"speed").value=360.0;await frames()
 maker._option("speed","min",1.0);await frames()
 var exposure
 for node in maker.view.find_children("*","CheckBox",true,false):
  if node.get_meta("exposed_key","")=="speed":exposure=node
 check(exposure!=null,"每个声明参数可人工选择开放")
 if exposure!=null:exposure.button_pressed=false
 await frames()
 check("speed" not in maker.current().exposed_parameters,"隐藏字段保存到预设")
 var source_id=maker.selected_id
 maker.view.get_node("%CreateSkill").pressed.emit();await frames(6)
 check(studio.current() is STGBarrageSkill and studio.current().attack_preset!=null,"预设生成可被敌人调用的具体招式")
 check(studio.inspector_tabs.tab_count==1 and studio.inspector_tabs.get_tab_title(0)=="程序参数","程序招式不出现旧阶段编辑页")
 check(parameter(studio.inspector,"speed")==null and parameter(studio.inspector,"count")!=null,"普通属性页仅显示开放字段")
 check(studio.canvas.world.issue.is_empty(),"生成后正式预览有效："+studio.canvas.world.issue)
 var count=parameter(studio.inspector,"count")
 if count!=null:
  count.value=5;await frames()
  check(studio.current().program_parameters.count==5,"策划覆盖值写入招式")
  check(studio.session.project.find("attack_presets",source_id).default_parameters.count==9,"策划改值不污染预设")
  studio.undo_edit();await frames()
  check(parameter(studio.inspector,"count").value==9,"撤销恢复预设默认值并无信号同步")
  studio.redo_edit();await frames()
  check(studio.current().program_parameters.count==5,"重做恢复覆盖值")
 var folder="res://tests/.test_run_logs/attack_program_ui"
 DirAccess.make_dir_recursive_absolute(folder)
 RenderingServer.force_draw(false);root.get_texture().get_image().save_png(folder+"/skill.png")
 studio.open_attack_presets(source_id);await frames()
 maker.view.get_node("%Name").text="技术策划预设"
 maker.view.get_node("%Name").text_submitted.emit("技术策划预设")
 await frames()
 check(maker.current().title=="技术策划预设" and studio.current().attack_preset.title!="技术策划预设","预设修改与已有招式快照隔离")
 RenderingServer.force_draw(false);root.get_texture().get_image().save_png(folder+"/maker.png")
 for dimensions in [Vector2i(1100,760),Vector2i(1440,900),Vector2i(2560,1440)]:
  root.size=dimensions;maker.size=Vector2i(1100,800);maker.popup_centered_clamped(maker.size,0.85)
  for percent in [100,150,200]:
   studio.set_ui_scale(percent,false);await frames()
   check(maker.view.position.is_equal_approx(Vector2.ZERO) and maker.view.size.x<=maker.size.x+1 and maker.view.size.y<=maker.size.y+1 and maker.size.x<=root.size.x and maker.size.y<=root.size.y,"预设制作页在%s/%d%%时保持窗口边界"%[dimensions,percent])
   if dimensions==Vector2i(1100,760) and percent==200:
    check(maker.view.get_node("%Split").size.y>=400 and maker.position.y>=40,"小窗口高缩放下完整保留属性编辑区，由外层滚动到达")
    maker.view.get_node("%OuterScroll").scroll_vertical=100000;await frames()
    RenderingServer.force_draw(false);root.get_texture().get_image().save_png(folder+"/maker_small_200.png")
 root.size=Vector2i(1440,900)
 maker.hide();studio.set_ui_scale(150,false);await frames()
 check(studio.current().program_parameters.count==5,"UI缩放不改程序参数")
 studio.set_ui_scale(100,false)
 maker.hide()
 for preset in studio.session.project.attack_presets:
  studio.add_program_attack(preset.id)
  await frames()
  var steps=24 if preset.program.capability=="Polyline2D" else 120
  for tick in steps:studio.canvas.world.step()
  await frames()
  check(studio.canvas.world.issue.is_empty() and not studio.canvas.world.actors.is_empty(),"实际渲染参考程序："+preset.title)
  RenderingServer.force_draw(false);root.get_texture().get_image().save_png(folder+"/"+preset.program.capability+".png")
 studio.session.recoverable_changes=false
 studio.queue_free();await frames(8)
 print("ATTACK PROGRAM UI RESULT: %d checks, %d failures"%[checks,failures])
 quit(1 if failures else 0)
