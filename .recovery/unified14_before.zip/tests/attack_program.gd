extends SceneTree
## 新 SDK 的定向验收，不逐库重跑旧内容。
const D=preload("res://addons/stg_maker/authoring/defaults.gd")
const Factory=preload("res://addons/stg_maker/authoring/attack_presets.gd")
const Copy=preload("res://stg/definitions/config_copy.gd")
const Compiler=preload("res://addons/stg_maker/build/compiler.gd")
const Assets=preload("res://addons/stg_maker/authoring/asset_store.gd")
var checks=0
var failures=0
class Probe:
 extends STGAttackProgram
 static var contexts=[]
 static var handles=[]
 static var cancellations=[]
 func start(ctx:STGAttackContext,_p:Dictionary):
  contexts.append(ctx);handles.append(ctx.spawn_body(ctx.origin(),Vector2.ZERO,0.2))
 func tick(ctx:STGAttackContext,_dt:float):
  if ctx.elapsed()>=0.3:ctx.finish()
 func cancel(reason:String):cancellations.append(reason)
class AreaProbe:
 extends STGAttackProgram
 static var context: STGAttackContext
 static var handle: STGAttackHandle
 func start(ctx:STGAttackContext,_p:Dictionary):
  context=ctx;handle=ctx.create_area(ctx.origin(),0.2)
func _initialize():run.call_deferred()
func check(ok:bool,message:String):
 checks+=1
 if not ok:failures+=1;push_error(message)
func library()->STGProject:
 var project=STGProject.create();D.populate(project);Factory.populate(project)
 return project
func world(project:STGProject,id:String):
 var simulation=STGSimulation.new();root.add_child(simulation);simulation.reset(project,"barrages",id)
 return simulation
func dispose(simulation):simulation.clear_attacks();simulation.free()
func run():
 var project=library()
 check(project.validate().is_empty(),"参考预设与素材通过全量校验："+"；".join(project.validate()))
 check(project.attack_presets.size()==4,"四种程序预设已建立")
 for preset in project.attack_presets:
  var skill=Factory.skill(preset);project.barrages.append(skill)
  var original_width=project.find("bullets",preset.material_id).visual.geometry.size.y
  var simulation=world(project,skill.id)
  check(simulation.issue.is_empty(),"程序可以由原招式入口启动："+preset.title)
  simulation.step()
  check(simulation.actors.size()>0 and simulation.issue.is_empty(),"程序生成实体："+preset.title+simulation.issue)
  var first=simulation.actors[0] if not simulation.actors.is_empty() else null
  if first!=null:
   check(first.owner_id==simulation.barrages[0].owner_id,"实体保持招式归属")
   if preset.program.capability=="Body2D":check(first.entity_session!=null and first.entity_session.implementation!=null,"每颗跟踪弹拥有实体级程序")
   if preset.program.capability=="Beam2D":
    check(not first.damaging,"激光代码阶段初始预警不判伤")
    for i in 90:simulation.step()
    check(first.damaging,"预警结束后进入扫射阶段")
   if preset.program.capability=="Polyline2D":
    var points=first.points.duplicate();simulation.reset(project,"barrages",skill.id);simulation.step()
    check(simulation.actors[0].points==points,"同种子雷电路径确定可重播")
   if preset.program.capability=="Trail2D":
    for i in 120:simulation.step()
    check(not first.segments.is_empty(),"动态拖尾复用正式路径采样")
  for i in 1000:
   if simulation.completed or not simulation.issue.is_empty():break
   simulation.step()
  check(simulation.issue.is_empty() and simulation.completed,"攻击及附属实体自然完成："+preset.title+simulation.issue)
  check(project.find("bullets",preset.material_id).visual.geometry.size.y==original_width,"实例几何不改写共享素材")
  dispose(simulation)
  var closure=Compiler.compile_library(project,[{"collection":"barrages","id":skill.id}])
  check(closure.issue.is_empty() and closure.library.barrages.size()==1,"引用闭包可编译程序招式："+preset.title)
 var preset=project.attack_presets[0]
 var independent=Factory.skill(preset)
 var original=independent.attack_preset.default_parameters.speed
 preset.default_parameters.speed=300
 check(independent.attack_preset.default_parameters.speed==original,"生成招式时预设快照隔离")
 independent.program_parameters.speed=210
 independent.attack_preset.exposed_parameters.erase("speed")
 check(not independent.attack_preset.validate(project,independent.program_parameters).is_empty(),"拒绝覆盖未开放参数")
 independent.program_parameters.clear()
 independent.attack_preset.material_id=project.attack_presets[1].material_id
 check(not independent.attack_preset.validate(project).is_empty(),"拒绝不兼容素材")
 var save="user://attack_program_checks_%d/library.tres"%Time.get_ticks_usec()
 check(Assets.save_library(project,save).is_empty(),"预设及程序招式通过正式事务保存")
 var loaded=preload("res://addons/stg_maker/authoring/document_loader.gd").library(save)
 check(loaded.issue.is_empty() and loaded.resource.attack_presets.size()==4 and loaded.resource.barrages[-1].attack_preset!=null,"重开保留预设、参数和声明")
 await handle_checks()
 await integration_checks()
 await boundary_checks()
 reference_checks()
 print("ATTACK PROGRAM RESULT: %d checks, %d failures"%[checks,failures])
 quit(1 if failures else 0)
func handle_checks():
 var project=library()
 var preset=Copy.copy(project.attack_presets[0])
 var definition=STGAttackProgramDefinition.new();definition.id="probe";definition.title="Probe";definition.implementation=Probe.new().get_script()
 preset.program=definition;preset.default_parameters={};preset.exposed_parameters.clear()
 var skill=Factory.skill(preset);project.barrages.append(skill)
 Probe.contexts.clear();Probe.handles.clear();Probe.cancellations.clear()
 var simulation=world(project,skill.id)
 simulation.play_barrage(skill.id,simulation.boss)
 simulation.step()
 check(Probe.contexts.size()==2 and Probe.handles.size()==2,"两次释放状态隔离")
 if Probe.contexts.size()==2:
  var a=Probe.contexts[0];var b=Probe.contexts[1];var old=Probe.handles[0]
  check(a.valid(old) and not b.valid(old),"句柄检查执行归属")
  check(not b.set_transform(old,Vector2.ZERO),"拒绝跨程序修改实体")
  simulation.stop_owner(simulation.barrages[0].owner_id)
  check(not a.active() and not a.set_transform(old,Vector2.ZERO),"取消关闭上下文且拒绝后续提交")
  simulation.reset(project,"barrages",skill.id);simulation.step()
  check(not Probe.contexts[-1].valid(old),"重播后旧代次句柄失效")
  check(Probe.cancellations.size()==2,"替换和取消每个执行只通知一次")
 dispose(simulation)
 Probe.contexts.clear();Probe.handles.clear();Probe.cancellations.clear()
 await process_frame

func integration_checks():
 var project=library()
 var skill=Factory.skill(project.attack_presets[0]);project.barrages.append(skill)
 var simulation=world(project,skill.id);simulation.step()
 var cast=simulation.barrages[0];var actor=simulation.actors[0]
 var initial=actor.velocity
 cast.cancel()
 simulation.player=actor.position+Vector2(0,-200)
 for i in 30:simulation.step()
 check(actor.alive and actor.entity_session.implementation!=null and actor.velocity!=initial,"不清屏时实体级程序在招式取消后继续运行")
 simulation.stop_owner(cast.owner_id)
 check(simulation.count_owned(cast.owner_id)==0,"明确清屏仍清理全部归属实体")
 dispose(simulation)
 var beam=Factory.skill(project.attack_presets[1]);project.barrages.append(beam)
 simulation=world(project,beam.id);simulation.step()
 cast=simulation.barrages[0]
 cast.origin+=Vector2(25,10)
 simulation.step()
 check(simulation.actors[0].points[0]==cast.origin,"既有敌人原点跟随接口作用于程序上下文")
 var beam_actor=simulation.actors[0]
 var handle=STGAttackHandle.new();handle._battle=simulation.attack_epoch;handle._execution=cast.get_instance_id();handle._ticket=1
 var before=beam_actor.points.duplicate()
 var translation=Vector2(14,21)
 check(cast.context.set_transform(handle,beam_actor.program_position()+translation,beam_actor.rotation),"持久激光句柄接受变换")
 check(beam_actor.points[0].is_equal_approx(before[0]+translation) and beam_actor.points[-1].is_equal_approx(before[-1]+translation),"激光变换同步更新外观和碰撞使用的几何")
 dispose(simulation)
 var action=D.action()
 action.windup=0.05;action.recovery=0.05;action.attack.enabled=true;action.attack.barrage_id=skill.id
 action.attack.finish_event="emission";action.attack.clear_on_end=false;action.end_when="attack"
 project.bosses[0].phases[0].behavior_flow=D.flow([action])
 simulation=STGSimulation.new();root.add_child(simulation);simulation.reset(project,"bosses",project.bosses[0].id)
 for i in 60:simulation.step()
 check(simulation.issue.is_empty() and not simulation.actors.is_empty(),"原敌人动作节点释放程序招式并保留已发弹体")
 dispose(simulation)
 await process_frame

func boundary_checks():
 var project=library()
 var preset=Copy.copy(project.attack_presets[0])
 preset.parameter_options.speed={"min":0.0,"max":5000.0}
 check(not preset.validate(project).is_empty(),"拒绝通过预设放宽程序边界")
 preset.parameter_options.speed={"min":{},"max":500.0}
 check(not preset.validate(project).is_empty(),"错误包装元数据返回定位提示")
 preset.parameter_options.clear()
 var definition=STGAttackProgramDefinition.new();definition.id="area_probe";definition.title="Area Probe";definition.capability="Area2D";definition.implementation=AreaProbe.new().get_script()
 preset.program=definition;preset.default_parameters={};preset.exposed_parameters.clear()
 var material=D.bullet("area");project.bullets.append(material);preset.material_id=material.id
 var skill=Factory.skill(preset);project.barrages.append(skill)
 var simulation=world(project,skill.id);simulation.step()
 check(simulation.issue.is_empty() and AreaProbe.context.valid(AreaProbe.handle),"Area2D 能力通过统一入口创建")
 if not simulation.actors.is_empty():
  var actor=simulation.actors[0]
  check(actor._program_hits(actor.position,1) and not actor._program_hits(actor.position+Vector2(10000,0),1),"区域实体复用正式碰撞几何")
  check(AreaProbe.context.set_active(AreaProbe.handle,false) and not actor.damaging,"预警开关统一撤销判伤")
  AreaProbe.context.set_transform(AreaProbe.handle,Vector2(INF,0))
  check(not simulation.issue.is_empty() and not actor.alive and not AreaProbe.context.active(),"非有限坐标拒绝并清理失败程序")
 dispose(simulation)
 AreaProbe.context=null;AreaProbe.handle=null
 await process_frame

func reference_checks():
 var source=library()
 var preset=Copy.copy(source.attack_presets[0])
 var definition=STGAttackProgramDefinition.new();definition.id="reference_probe";definition.title="Reference Probe";definition.implementation=Probe.new().get_script()
 definition.fields.assign([{"name":"default_ref","type":"resource_id","collection":"bullets","default":preset.material_id},{"name":"override_ref","type":"resource_id","collection":"bullets","default":preset.material_id}])
 preset.program=definition;preset.default_parameters={"default_ref":preset.material_id};preset.exposed_parameters=PackedStringArray(["override_ref"])
 var extra=D.bullet("moving");source.bullets.append(extra)
 var skill=Factory.skill(preset);skill.program_parameters.override_ref=extra.id;skill.material_override=extra.id;source.barrages.append(skill)
 var target=STGProject.create()
 var bundle=preload("res://addons/stg_maker/authoring/template_import.gd").copy_bundle(target,source,"barrages",skill.id,"imported_")
 check(bundle.issues.is_empty(),"程序招式按正式导入路径复制资源闭包")
 for entry in bundle.entries:target.get(entry[0]).append(entry[1])
 var imported=target.find("barrages",bundle.selected_id)
 check(imported!=null and imported.material_override=="imported_"+extra.id,"导入重映射写入素材覆盖字段")
 check(imported.attack_preset.default_parameters.default_ref=="imported_"+preset.material_id and imported.program_parameters.override_ref=="imported_"+extra.id,"默认与覆盖资源参数分别重映射到实际存储")
 check(target.validate().is_empty(),"导入后的程序招式没有悬空引用："+"；".join(target.validate()))
 check(skill.material_override==extra.id and definition.fields[0].default==preset.material_id,"导入不改写源招式或共享程序声明")
