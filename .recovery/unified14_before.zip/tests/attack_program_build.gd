extends SceneTree
## 只构建新SDK闭环测试夹具，不逐个导出现有示例工程。
const Factory=preload("res://addons/stg_maker/authoring/attack_presets.gd")
const D=preload("res://addons/stg_maker/authoring/defaults.gd")
const Builder=preload("res://addons/stg_maker/build/project_builder.gd")
const Commands=preload("res://addons/stg_maker/ui/commands.gd")
var checks=0
var failures=0
func _initialize():run.call_deferred()
func check(ok:bool,message:String):
 checks+=1
 if not ok:failures+=1;push_error(message)
func run():
 var game=preload("res://tests/game_fixture.gd").create()
 Factory.populate(game.library)
 var actions:Array[STGBossAction]=[]
 var skills=[]
 for preset in game.library.attack_presets:
  var skill=Factory.skill(preset);game.library.barrages.append(skill);skills.append(skill)
  var action=D.action();action.windup=0;action.recovery=0;action.end_when="attack"
  action.attack.enabled=true;action.attack.barrage_id=skill.id;action.attack.finish_event="cleared"
  actions.append(action)
 game.library.bosses[0].phases[0].behavior_flow=D.flow(actions)
 check(game.validate().is_empty(),"新SDK独立游戏夹具有效："+"；".join(game.validate()))
 var path="user://attack_sdk_prefab_%d.tscn"%Time.get_ticks_usec()
 var host={"session":{"project":game.library},"collection":"barrages","selected_id":skills[0].id}
 check(Commands.export_prefab(host,path).is_empty(),"新招式可以导出预制体")
 var packed=load(path)
 var prefab=packed.instantiate();root.add_child(prefab)
 for i in 3:await process_frame
 check(prefab.simulation!=null and prefab.simulation.issue.is_empty(),"预制体使用同一正式运行器")
 check(prefab.simulation.boss==Vector2.ZERO,"预制体原点接入保持原契约")
 prefab.queue_free()
 for i in 3:await process_frame
 var output="user://attack_sdk_export_%d"%Time.get_ticks_usec()
 var built=Builder.build(game,output)
 check(built.issue.is_empty(),"SDK游戏项目构建成功："+built.issue)
 if built.issue.is_empty():
  check(not DirAccess.dir_exists_absolute(output.path_join("addons")),"成品不包含编辑器")
  var verifier=FileAccess.open(output.path_join("verify_attack_sdk.gd"),FileAccess.WRITE)
  verifier.store_string('''extends SceneTree
func _initialize():run.call_deferred()
func run():
 var game=load("res://game/content/game.tres")
 var valid=game!=null and game.validate().is_empty()
 var count=0
 if valid:
  for skill in game.library.barrages:
   if skill.attack_preset==null:continue
   var world=STGSimulation.new();root.add_child(world);world.reset(game.library,"barrages",skill.id)
   for i in 24:world.step()
   valid=valid and world.issue.is_empty() and not world.actors.is_empty()
   count+=1
   world.clear_attacks();world.free()
 valid=valid and count==4
 print("EXPORTED ATTACK SDK RESULT: 4 checks, %d failures"%(0 if valid else 1))
 quit(0 if valid else 1)
''');verifier.close()
  var log:Array=[]
  var code=preload("res://tests/export_runtime.gd").import_project(ProjectSettings.globalize_path(output),log)
  check(code==0 and not Builder._has_errors(log),"导出工程脱离源缓存导入："+"\n".join(log))
  log.clear()
  code=preload("res://tests/export_runtime.gd").run(ProjectSettings.globalize_path(output),log,"verify_attack_sdk.gd",2000)
  check(code==0 and not Builder._has_errors(log) and "EXPORTED ATTACK SDK RESULT: 4 checks, 0 failures" in "\n".join(log),"成品运行全部四类程序："+"\n".join(log))
 print("ATTACK PROGRAM BUILD RESULT: %d checks, %d failures"%[checks,failures])
 quit(1 if failures else 0)
