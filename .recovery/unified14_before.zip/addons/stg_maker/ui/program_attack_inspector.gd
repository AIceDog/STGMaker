@tool
extends RefCounted
const Fields = preload("res://addons/stg_maker/ui/attack_parameter_fields.gd")
const Form = preload("res://addons/stg_maker/ui/form_scene.gd")
static func build(host, parent: Node, skill: STGBarrageSkill) -> void:
	var view = load("res://addons/stg_maker/ui/forms/program_attack_properties.tscn").instantiate()
	parent.add_child(view)
	view.theme = null
	Form.snapshot(view)
	var preset = skill.attack_preset
	var title: LineEdit = view.get_node("%Title")
	title.text = skill.title
	var commit = func():
		if host.current()!=null and title.text!=host.current().title: host.edit_path([],"title",title.text)
	title.text_submitted.connect(func(_value):commit.call())
	title.focus_exited.connect(commit)
	view.get_node("%Program").text = "程序：%s · %s\n预设快照：%s（修改原预设不会改写此招式）" % [preset.program.title if preset.program!=null else "未设置",preset.program.capability if preset.program!=null else "",preset.title]
	var source_material = host.session.project.find("bullets",preset.material_id)
	var ids: Array = [""]; var names: Array = ["预设素材 · "+(source_material.title if source_material!=null else "引用丢失")]
	if preset.program != null:
		for material in host.session.project.bullets:
			if preset.program.capability in material.supported_capabilities(): ids.append(material.id); names.append(material.title)
	var selector: OptionButton = view.get_node("%Material")
	for name in names: selector.add_item(name)
	selector.select(ids.find(skill.material_override))
	selector.disabled = not preset.allow_material_override
	view.get_node("%EditMaterial").pressed.connect(func():
		var current = host.current()
		if current is STGBarrageSkill and current.attack_preset != null: host.edit_reference("bullets",current.attack_preset.material_id if current.material_override.is_empty() else current.material_override))
	selector.item_selected.connect(func(index):host.edit_path([],"material_override",ids[index],true))
	if preset.program != null and preset.program.validate_fields().is_empty():
		var values = preset.parameters(skill.program_parameters)
		for field in preset.fields():
			if str(field.name) not in preset.exposed_parameters: continue
			var key = str(field.name)
			Fields.add(view.get_node("%Parameters"),field,values.get(key),func(value):
				host.edit_configuration([],func(target,_project):target.program_parameters[key]=value,false,key),host.session.project)
	var life = preset.lifecycle
	view.get_node("%Summary").text = "伤害 %s · 命中间隔 %s秒\n招式内部阶段由代码定义；敌人的准备、移动与收招继续在行为节点中配置。" % [life.damage,life.hit_interval] if life!=null else "预设缺少生命周期"
	view.get_node("%Maker").pressed.connect(host.open_attack_presets)
	Form.apply_display(view,host.get_meta("display_unit",1.0),host.Display)
static func sync(host) -> void:
	var skill = host.current()
	if skill is STGBarrageSkill and skill.attack_preset != null:
		Fields.sync(host.inspector,skill.attack_preset.parameters(skill.program_parameters))
		for child in host.inspector.get_children():
			var title = child.get_node_or_null("%Title")
			if title is LineEdit and title.text!=skill.title: title.text=skill.title
