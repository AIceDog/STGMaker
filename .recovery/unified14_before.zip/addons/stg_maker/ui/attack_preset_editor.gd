@tool
extends Window
## 制作模板独立于日常招式页；所有编辑走同一会话历史和正式资产保存。
const Factory = preload("res://addons/stg_maker/authoring/attack_presets.gd")
const Parameters = preload("res://addons/stg_maker/ui/attack_parameter_fields.gd")
const F = preload("res://addons/stg_maker/ui/fields.gd")
const Form = preload("res://addons/stg_maker/ui/form_scene.gd")
var host
var view: Control
var selected_id: String = ""
var programs: Array[STGAttackProgramDefinition] = []
var _structure: Array = []
var _list_key: Array = []
var _syncing: bool = false
func open_for(workspace) -> void:
	host = workspace
	title = "程序预设制作"
	view = load("res://addons/stg_maker/ui/forms/attack_preset_editor.tscn").instantiate()
	theme = host.theme
	view.theme = null
	add_child(view)
	Form.snapshot(view)
	Form.apply_display(view,host.get_meta("display_unit",1.0),host.Display)
	min_size = Vector2i(800,600)
	size = Vector2i(1100,800)
	close_requested.connect(func():commit_pending();hide())
	view.get_node("%Close").pressed.connect(func():commit_pending();hide())
	view.get_node("%List").item_selected.connect(func(index):commit_pending();selected_id=view.get_node("%List").get_item_metadata(index);_sync())
	view.get_node("%New").pressed.connect(_new)
	view.get_node("%References").pressed.connect(func():host.session.edit(func(project):Factory.populate(project)))
	view.get_node("%Remove").pressed.connect(func():
		var id=selected_id
		host.session.edit(func(project):project.attack_presets=project.attack_presets.filter(func(p):return p.id!=id)))
	view.get_node("%Undo").pressed.connect(func():commit_pending();host.session.undo())
	view.get_node("%Redo").pressed.connect(func():commit_pending();host.session.redo())
	view.get_node("%CreateSkill").pressed.connect(func():
		commit_pending()
		if current()==null:return
		var issues=current().validate(host.session.project)
		if not issues.is_empty():view.get_node("%Status").text="；".join(issues);return
		host.add_program_attack(selected_id);hide())
	view.get_node("%Save").pressed.connect(func():commit_pending();host.save_project())
	for key in ["Name","Category"]:
		var control:LineEdit=view.get_node("%"+key)
		var property="title" if key=="Name" else "category"
		var commit=func():
			if current()!=null and current().get(property)!=control.text:_edit(func(p):p.set(property,control.text))
		control.text_submitted.connect(func(_s):commit.call())
		control.focus_exited.connect(commit)
	view.get_node("%Description").focus_exited.connect(func():
		if current()!=null and current().description!=view.get_node("%Description").text:_edit(func(p):p.description=view.get_node("%Description").text))
	view.get_node("%Program").item_selected.connect(func(index):
		if index<0 or index>=programs.size():return
		var chosen=programs[index]
		_edit(func(p):
			p.program=chosen;p.default_parameters=chosen.default_parameters();p.exposed_parameters.clear();p.parameter_options.clear()
			for field in chosen.fields:p.exposed_parameters.append(str(field.name))
			var compatible=host.session.project.bullets.filter(func(m):return chosen.capability in m.supported_capabilities())
			p.material_id=compatible[0].id if not compatible.is_empty() else "",true))
	view.get_node("%Material").item_selected.connect(func(index):
		var id=str(view.get_node("%Material").get_item_metadata(index))
		_edit(func(p):p.material_id=id))
	view.get_node("%MaterialOverride").toggled.connect(func(enabled):
		if not _syncing:_edit(func(p):p.allow_material_override=enabled))
	view.get_node("%Damage").value_changed.connect(func(value):
		if not _syncing:_edit(func(p):p.lifecycle.damage=value,false,"damage"))
	view.get_node("%HitInterval").value_changed.connect(func(value):
		if not _syncing:_edit(func(p):p.lifecycle.hit_interval=value,false,"hit_interval"))
	view.get_node("%LoadProgram").pressed.connect(func():_choose("program"))
	for pair in [["SpawnEffect","spawn_effect"],["HitEffect","hit_effect"],["ExpireEffect","expire_effect"],["SpawnSound","spawn_sound"]]:
		var button:Button=view.get_node("%"+pair[0])
		button.set_meta("resource_label",button.text)
		button.pressed.connect(func():_choose(pair[1]))
		button.gui_input.connect(func(event):
			if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_RIGHT and event.pressed:
				_edit(func(p):p.lifecycle.set(pair[1],null));button.accept_event())
	host.session.changed.connect(_sync)
	_sync()
	popup_centered_clamped(size,0.85)
func current() -> STGAttackPreset:return host.session.project.find("attack_presets",selected_id) if host!=null else null
func commit_pending() -> void:
	var focus=gui_get_focus_owner()
	if focus!=null:focus.release_focus()
func _edit(change:Callable,structure:bool=false,key:String="") -> void:
	if current()==null:return
	var id=selected_id
	var focus=gui_get_focus_owner()
	var merge=""
	if not key.is_empty() and focus!=null and (focus is SpinBox or focus.get_parent() is SpinBox):merge="preset/%s/%s/%s"%[id,key,focus.get_instance_id()]
	host.session.edit_asset("attack_presets",id,func(project):change.call(project.find("attack_presets",id)),{"structure":false,"collection":"attack_presets","id":id,"field":key},merge)
	if structure:_structure.clear();_sync()
func _new() -> void:
	commit_pending()
	var preset=STGAttackPreset.new()
	preset.id=host.Commands.Defaults.uid("attack_preset")
	preset.program=Factory.definitions()[0]
	preset.default_parameters=preset.program.default_parameters()
	for field in preset.program.fields:preset.exposed_parameters.append(str(field.name))
	var materials=host.session.project.bullets.filter(func(m):return "Body2D" in m.supported_capabilities())
	if not materials.is_empty():preset.material_id=materials[0].id
	selected_id=preset.id
	host.session.edit(func(project):project.attack_presets.append(preset))
func _sync() -> void:
	if host==null or view==null or _syncing:return
	_syncing=true
	var project=host.session.project
	if current()==null:selected_id=project.attack_presets[0].id if not project.attack_presets.is_empty() else ""
	var key=[]
	for preset in project.attack_presets:key.append([preset.id,preset.title,preset.category])
	var list:ItemList=view.get_node("%List")
	if key!=_list_key:
		_list_key=key;list.clear()
		for preset in project.attack_presets:list.add_item(preset.category+" · "+preset.title);list.set_item_metadata(list.item_count-1,preset.id)
	for index in list.item_count:
		if list.get_item_metadata(index)==selected_id:list.select(index)
	view.get_node("%Undo").disabled=host.session.undo_stack.is_empty()
	view.get_node("%Redo").disabled=host.session.redo_stack.is_empty()
	var preset=current()
	view.get_node("%Properties").visible=preset!=null
	view.get_node("%Remove").disabled=preset==null
	view.get_node("%CreateSkill").disabled=preset==null
	if preset==null:
		view.get_node("%Status").text="新建预设，或添加四个参考预设。";_syncing=false;return
	for pair in [["Name",preset.title],["Category",preset.category],["Description",preset.description]]:
		var control=view.get_node("%"+pair[0])
		if control.text!=pair[1]:control.text=pair[1]
	view.get_node("%MaterialOverride").set_pressed_no_signal(preset.allow_material_override)
	if preset.lifecycle!=null:
		view.get_node("%Damage").set_value_no_signal(preset.lifecycle.damage)
		view.get_node("%HitInterval").set_value_no_signal(preset.lifecycle.hit_interval)
	for pair in [["SpawnEffect","spawn_effect"],["HitEffect","hit_effect"],["ExpireEffect","expire_effect"],["SpawnSound","spawn_sound"]]:
		var button:Button=view.get_node("%"+pair[0])
		var resource=preset.lifecycle.get(pair[1]) if preset.lifecycle!=null else null
		var path=resource.resource_path if resource!=null else ""
		button.tooltip_text=(path if not path.is_empty() else "未设置")+"\n左键选择，右键清除。"
		button.text=str(button.get_meta("resource_label"))+(" ✓" if resource!=null else "")
	var structure=[preset.id,preset.program,preset.parameter_options,project.bullets.map(func(m):return [m.id,m.title,m.form])]
	if structure!=_structure:
		_structure=structure.duplicate(true)
		_rebuild(preset)
	Parameters.sync(view.get_node("%Parameters"),preset.parameters())
	for control in view.get_node("%Parameters").find_children("*","CheckBox",true,false):
		if control.has_meta("exposed_key"):control.set_pressed_no_signal(str(control.get_meta("exposed_key")) in preset.exposed_parameters)
	var errors=preset.validate(project)
	view.get_node("%Status").text="；".join(errors) if not errors.is_empty() else "预设有效 · 只开放勾选字段；生成招式保存独立快照。"
	view.get_node("%CreateSkill").disabled=not errors.is_empty()
	_syncing=false
func _rebuild(preset:STGAttackPreset) -> void:
	programs=Factory.definitions()
	if preset.program!=null and not programs.has(preset.program):programs.append(preset.program)
	var select:OptionButton=view.get_node("%Program");select.clear()
	for program in programs:select.add_item(program.title+" · "+program.capability)
	select.select(programs.find(preset.program))
	select=view.get_node("%Material");select.clear()
	if preset.program!=null:
		for material in host.session.project.bullets:
			if preset.program.capability in material.supported_capabilities():
				select.add_item(material.title);select.set_item_metadata(select.item_count-1,material.id)
				if material.id==preset.material_id:select.select(select.item_count-1)
	var box=view.get_node("%Parameters")
	for child in box.get_children():box.remove_child(child);child.queue_free()
	if preset.program==null or not preset.program.validate_fields().is_empty():return
	var values=preset.parameters()
	for field in preset.fields():
		var field_key=str(field.name)
		var card=F.group(box,str(field.get("label",field_key)))
		# 制作默认值使用程序原始边界，允许修正暂时落在开放范围之外的默认值。
		var default_field=preset.program.fields.filter(func(f):return str(f.name)==field_key)[0].duplicate(true)
		default_field["label"]=field.get("label",field_key);default_field["help"]=field.get("help","")
		Parameters.add(card,default_field,values.get(field_key),func(value):_edit(func(p):p.default_parameters[field_key]=value,false,field_key),host.session.project)
		var expose=CheckBox.new();expose.text="向策划开放";expose.set_meta("exposed_key",field_key);card.add_child(expose)
		expose.set_pressed_no_signal(field_key in preset.exposed_parameters)
		expose.toggled.connect(func(enabled):_edit(func(p):
			if enabled and field_key not in p.exposed_parameters:p.exposed_parameters.append(field_key)
			elif not enabled:p.exposed_parameters.erase(field_key)))
		F.text(card,"策划显示名称",str(field.get("label",field_key)),func(value):_option(field_key,"label",value))
		F.text(card,"参数说明",str(field.get("help","")),func(value):_option(field_key,"help",value))
		if str(field.type) in ["float","int"]:
			F.number(card,"允许最小值",float(field.get("min",-100000)),func(value):_option(field_key,"min",value),-100000,100000)
			F.number(card,"允许最大值",float(field.get("max",100000)),func(value):_option(field_key,"max",value),-100000,100000)
	for child in box.find_children("*","Control",true,false):
		if child.get_meta("form_fragment",false):Form.apply_display(child,host.get_meta("display_unit",1.0),host.Display)
func _option(key:String,property:String,value) -> void:
	_edit(func(p):
		if not p.parameter_options.has(key):p.parameter_options[key]={}
		p.parameter_options[key][property]=value,true)
func _choose(property:String) -> void:
	var dialog=FileDialog.new();dialog.access=FileDialog.ACCESS_RESOURCES;dialog.file_mode=FileDialog.FILE_MODE_OPEN_FILE
	dialog.filters=PackedStringArray(["*.tres ; 攻击程序声明"]) if property=="program" else (PackedStringArray(["*.wav,*.ogg,*.mp3 ; 音效"]) if property.ends_with("sound") else PackedStringArray(["*.tscn,*.scn ; 表现场景"]))
	add_child(dialog)
	dialog.file_selected.connect(func(path):
		var resource=load(path)
		if property=="program":
			if not resource is STGAttackProgramDefinition:host.message("请选择 STGAttackProgramDefinition 声明。");dialog.queue_free();return
			_edit(func(p):p.program=resource;p.default_parameters=resource.default_parameters();p.parameter_options.clear();p.exposed_parameters.clear(),true)
		elif property.ends_with("sound") and resource is AudioStream:_edit(func(p):p.lifecycle.set(property,resource))
		elif property.ends_with("effect") and resource is PackedScene:_edit(func(p):p.lifecycle.set(property,resource))
		else:host.message("资源类型不匹配。")
		dialog.queue_free())
	dialog.canceled.connect(dialog.queue_free);dialog.popup_centered_ratio(0.7)
func _exit_tree() -> void:
	if is_instance_valid(host) and host.session.changed.is_connected(_sync):host.session.changed.disconnect(_sync)

func apply_workspace_display(unit: float) -> void:
	if view == null: return
	Form.apply_display(view,unit,host.Display)
	for child in view.find_children("*","Control",true,false):
		if child.get_meta("form_fragment",false): Form.apply_display(child,unit,host.Display)
