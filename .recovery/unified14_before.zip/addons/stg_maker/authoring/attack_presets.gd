@tool
extends RefCounted
const Copy = preload("res://stg/definitions/config_copy.gd")
const D = preload("res://addons/stg_maker/authoring/defaults.gd")
const PROGRAMS = ["homing","rotating_beam","lightning","dynamic_trail"]
static func definitions() -> Array[STGAttackProgramDefinition]:
	var result: Array[STGAttackProgramDefinition] = []
	for name in PROGRAMS: result.append(load("res://stg/programs/"+name+".tres"))
	return result
static func populate(project: STGProject) -> void:
	for program in definitions():
		if project.attack_presets.any(func(p): return p != null and p.program == program): continue
		var candidates = project.bullets.filter(func(m): return program.capability in m.supported_capabilities())
		if candidates.is_empty():
			var material = D.bullet({"Body2D":"moving","Beam2D":"laser","Polyline2D":"laser","Trail2D":"trail","Area2D":"area"}[program.capability])
			project.bullets.append(material); candidates.append(material)
		var preset = STGAttackPreset.new()
		preset.id = D.uid("attack_preset"); preset.title = program.title; preset.category = "程序参考"
		preset.program = program; preset.material_id = candidates[0].id
		preset.default_parameters = program.default_parameters()
		for field in program.fields: preset.exposed_parameters.append(str(field.name))
		preset.lifecycle.exit_mode = "none"
		preset.lifecycle.hit_mode = "persistent" if program.capability=="Body2D" else "repeat"
		project.attack_presets.append(preset)
static func skill(preset: STGAttackPreset) -> STGBarrageSkill:
	var result = STGBarrageSkill.new()
	result.id = D.uid("program_attack"); result.title = preset.title; result.description = preset.description
	result.attack_preset = Copy.copy(preset)
	return result
